import mysql.connector
from datetime import datetime


database = mysql.connector.connect(
  host = "localhost",
  user = "administrador",
  password = "EE6zGqxZL5anUmst",
  database = "sistema_seguridad" )
  
cursor = database.cursor()

# Enviamos datos a la BBDD
def Manejador_Entrada(mensaje, ID_propietario):
	
	#Push into DB Table
     hora = datetime.now()
     fecha = hora.strftime("%d/%m/%Y %H:%M")
     print("Nombre: ",mensaje)
     print("A dia de: ",fecha)
     print("ID de la casa: ",ID_propietario)
     consulta = "INSERT INTO usuarios_casa (nombre, fecha, ID_propietario) VALUES (%s, %s, %s)"
     valores = (mensaje, fecha, ID_propietario)
     cursor.execute(consulta, valores)
     database.commit()



#===============================================================
# Seleccionamos la casa donde se ha producido el evento

def Manejador(Topic, mensaje):
	if Topic == "Entrada/entradaCasa":
		Manejador_Entrada(mensaje, 1)

#===============================================================
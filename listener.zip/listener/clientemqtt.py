import paho.mqtt.client as mqtt
from almacenador import Manejador

def on_connect(client, userdata, flags, rc):
  if (rc == 0):
    print ("Conexion exitosa")
  else:
    print ("Error de conexion")


def on_message(client, userdata, message):
  print('------------------------------')
  print("mensaje recibido: "+ str(message.payload.decode("utf-8")))
  print("topic: " + str(message.topic))
  Manejador(message.topic, str(message.payload.decode("utf-8")))

broker_address="138.201.164.206"
port=1883
#broker_address="iot.eclipse.org" #use external broker
client = mqtt.Client("lector") #create new instance
user="root"
password="EE6zGqxZL5anUmst"
client.username_pw_set(user,password=password)
client.on_connect=on_connect
client.on_message=on_message
client.connect(broker_address,port)
client.subscribe('Entrada/#')
#client.publish('esp/test',"string")
client.loop_forever()
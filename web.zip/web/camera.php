<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="estilos.css" rel="stylesheet" type="text/css">
<title>Face Recognition Access Control</title>

</head>
<body id="body">

<div id="cabecera">
    <h1>FACE RECOGNITION </h1>
    <img src="Camara.png">
</div>
<div>
  <h2>Indice</h2>
  <ul>
    <li><a href="quienes_somos.php">¿Quienes somos?</a></li>
    <li><a href="">Streaming</a></li>
    <li><a href="movimientos.php">Movimientos en la casa</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul></div>

<div id="content-left">
  <div id="stream-container" class="image-container"> <img id="stream" src=""> </div>
</div>
<div id="content-right">
  <div id="status-display"> <span id="current-status"></span> </div>
  <div id="person-name">
    <input id="person" type="text" value="" placeholder="Type the person's name here">
  </div>
  <div class="buttons">
    <button id="button-stream" class="left">STREAM CAMERA</button>
    <button id="button-detect" class="right">DETECT FACES</button>
  </div>
  <div class="buttons">
    <button id="button-capture" class="left" title="Enter a name above before capturing a face">ADD USER</button>
    <button id="button-recognise" class="right">ACCESS CONTROL</button>
  </div>
  <div class="people">
    <h3>Captured Faces</h3>
    <ul>
    </ul>
  </div>
  <div class="buttons">
    <button id="delete_all">DELETE ALL</button>
  </div>
</div>
<script>
document.addEventListener("DOMContentLoaded", function(event) {
  var baseHost = document.location.origin;
  var streamUrl = baseHost + ":81";
  const WS_URL = "ws://" + window.location.host + ":82";
  const ws = new WebSocket(WS_URL);

  const view = document.getElementById("stream");
  const personFormField = document.getElementById("person");
  const streamButton = document.getElementById("button-stream");
  const detectButton = document.getElementById("button-detect");
  const captureButton = document.getElementById("button-capture");
  const recogniseButton = document.getElementById("button-recognise");
  const deleteAllButton = document.getElementById("delete_all");

  // gain, frequency, duration
  a=new AudioContext();
  function alertSound(w,x,y){
    v=a.createOscillator();
    u=a.createGain();
    v.connect(u);
    v.frequency.value=x;
    v.type="square";
    u.connect(a.destination);
    u.gain.value=w*0.01;
    v.start(a.currentTime);
    v.stop(a.currentTime+y*0.001);
  }

  ws.onopen = () => {
    console.log(`Connected to ${WS_URL}`);
  };
  ws.onmessage = message => {
    if (typeof message.data === "string") {
      if (message.data.substr(0, 8) == "listface") {
        addFaceToScreen(message.data.substr(9));
      } else if (message.data == "delete_faces") {
        deleteAllFacesFromScreen();
      } else if (message.data == "door_open") {
          alertSound(10,233,100); alertSound(3,603,200);
      } else {
          document.getElementById("current-status").innerHTML = message.data;
          document.getElementById("status-display").style.background = "green";
      }
    }
    if (message.data instanceof Blob) {
      var urlObject = URL.createObjectURL(message.data);
      view.src = urlObject;
    }
  }

  streamButton.onclick = () => {
    ws.send("stream");
  };
  detectButton.onclick = () => {
    ws.send("detect");
  };
  captureButton.onclick = () => {
    person_name = document.getElementById("person").value;
    ws.send("capture:" + person_name);
  };
  recogniseButton.onclick = () => {
    ws.send("recognise");
  };
  deleteAllButton.onclick = () => {
    ws.send("delete_all");
  };
  personFormField.onkeyup = () => {
    captureButton.disabled = false;
  };

  function deleteAllFacesFromScreen() {
    // deletes face list in browser only
    const faceList = document.querySelector("ul");
    while (faceList.firstChild) {
      faceList.firstChild.remove();
    }
    personFormField.value = "";
    captureButton.disabled = true;
  }

  function addFaceToScreen(person_name) {
    const faceList = document.querySelector("ul");
    let listItem = document.createElement("li");
    let closeItem = document.createElement("span");
    closeItem.classList.add("delete");
    closeItem.id = person_name;
    closeItem.addEventListener("click", function() {
      ws.send("remove:" + person_name);
    });
    listItem.appendChild(
      document.createElement("strong")
    ).textContent = person_name;
    listItem.appendChild(closeItem).textContent = "X";
    faceList.appendChild(listItem);
  }

  captureButton.disabled = true;
});
</script>
</body>
</html>
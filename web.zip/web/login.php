<?php

  session_start();

  if (isset($_SESSION['user_id'])) {
    header('Location: /php-login');
  }
  require 'database.php';

  if (!empty($_POST['email']) && !empty($_POST['password'])) {
    $records = $conn->prepare('SELECT id, email, password FROM usuarios_registrados WHERE email = :email');
    $records->bindParam(':email', $_POST['email']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $message = '';

    if (count($results) > 0 && password_verify($_POST['password'], $results['password'])) {
      $_SESSION['user_id'] = $results['id'];
      header("Location: /quienes_somos.php");
    } else {
      $message = 'Estos datos no se corresponden con ningun usuario';
    }
  }

?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="estilos.css" rel="stylesheet" type="text/css">
<title>LOGIN</title>
</head>
<body id="body">

<div id="cabecera">
    <h1>LOGIN</h1>
    </div>
 <span> or <a href="signup.php">SIGNUP</a></span>
<form action="login.php" method="POST">
	<input type="text" name="email" placeholder="Enter your email">
	<input type="password" name="password" placeholder="Enter your password">
	<input type="submit" value="Send" >
</form>

</body>
</html>
<?php
  session_start();

  require 'database.php';

  if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT id, email, password FROM usuarios_registrados WHERE id = :id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
      $user = $results;
    }
  }
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="estilos.css" rel="stylesheet" type="text/css">
<title>INICIO DE SESION</title>
</head>
<body id="body">

<div id="cabecera">
    <h1>INICIO DE SESION</h1>
    </div>
    <?php if(!empty($user)): ?>
      <br> Welcome. <?= $user['email']; ?>
      <div>
  <h2>Indice</h2>
  <ul>
    <li><a href="quienes_somos.php">¿Quienes somos?</a></li>
    <li><a href="camera.php">Streaming</a></li>
    <li><a href="movimientos.php">Movimientos en la casa</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul></div>
      <br>Has iniciado correctamente la sesion
      <a href="logout.php">
        Logout
      </a>
    <?php else: ?>
 <a href="login.php"> Login</a> or
 <a href="signup.php"> SignUp</a> 
 <?php endif; ?>
 </body>
 </html>
<?php
  session_start();

  require 'database.php';
  if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT nombre,fecha FROM usuarios_casa WHERE ID_propietario =:id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    
    
    

  }
 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Movimientos en la casa</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="estilos.css" rel="stylesheet" type="text/css">
</head>

<body>

<div id="cabecera">
    <h1>Movimiento en la casa </h1>
    </div>
<div>
  <h2>Indice</h2>
  <ul>
    <li><a href="quienes_somos.php">¿Quienes somos?</a></li>
    <li><a href="camera.php">Streaming</a></li>
    <li><a href="">Movimientos en la casa</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul></div>
<div id="cuerpo">
  <h2>Datos del movimiento del hogar</h2>
  <table id="tablas">
        <tr>
            <th>Nombre</th> 
            <th>Fecha</th>
        </tr>
           <?php
     while ($results = $records->fetch(PDO::FETCH_ASSOC)) {
             ?>
            <tr>
                <td><?php echo $results['nombre'] ?></td>
                <td><?php echo $results['fecha'] ?></td>
            </tr>
            <?php
          }
          ?>
        </table>
        
   
 
     
      </div>
    </body>
    </html>
    
<?php

  require 'database.php';

  $message = '';

  if (!empty($_POST['email']) && !empty($_POST['password'])) {
    $sql = "INSERT INTO usuarios_registrados (email, password) VALUES (:email, :password)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email', $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $stmt->bindParam(':password', $password);

    if ($stmt->execute()) {
      $message = 'Usuario creado correctamente';
    } else {
      $message = 'Ya existe un usuario con estos valores';
    }
  }
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="estilos.css" rel="stylesheet" type="text/css">
<title>SIGNUP</title>
</head>
<body id="body">
 <?php if(!empty($message)): ?>
      <p> <?= $message ?></p>
    <?php endif; ?>
<div id="cabecera">
    <h1>SIGNUP</h1>
    </div>
<span> or <a href="login.php">LOGIN</a></span>
<form action="signup.php" method="post">
    <input type="text" name="email" placeholder="Enter your email">
    <input type="password" name="password" placeholder="Enter your password">
    <input type="submit" value="Send" >
</form>
</body>
</html>
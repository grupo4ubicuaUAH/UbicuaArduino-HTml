<!DOCTYPE html>
<html>
<head>
    <title>Quienes somos</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="estilos.css" rel="stylesheet" type="text/css">
</head>

<body>

<div id="cabecera">
    <h1>¿QUIENES SOMOS? </h1>
    </div>
<div>
  <h2>Indice</h2>
  <ul>
    <li><a href="">¿Quienes somos?</a></li>
    <li><a href="camera.php">Streaming</a></li>
    <li><a href="movimientos.php">Movimientos en la casa</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul></div>
<div id="cuerpo">
	<h2>Fundadores</h2>
	<table id="tablas">
        <tr>
            <th>Nombre</th> 
            <th>Correo</th>
            <th>Fecha de nacimiento</th>
        </tr>
        <tr>
            <td>Miguel Tejero Batanero</td> 
            <td><a href="mailto:m.tejero@edu.uah.es">m.tejero@edu.uah.es</a></td>
            <td>28/10/1999</td>
        </tr>
        <tr>
            <td>Javier Pastor Moreno</td> 
            <td><a href="mailto:javier.pastor@edu.uah.es">javier.pastor@edu.uah.es</a></td>
            <td>24/09/1999</td>
        </tr>
         <tr>
            <td>Rodrigo Becerra Villas</td> 
            <td><a href="mailto:rodrigo.becerra@edu.uah.es">rodrigo.becerra@edu.uah.es</a></td>
            <td>09/01/2000</td>
        </tr>
        <tr>
            <td>Guillermo Jimenez Fernandez</td> 
            <td><a href="mailto:guillermo.jimenez@edu.uah.es">guillermo.jimenez@edu.uah.es</a></td>
            <td>31/07/2000</td>
       </tr></table></div>
  <div>
    <h2>Información</h2>
    <p>Tras el acontecimiento que ha golpeado de manera global a nuestra sociedad, se han acentuado de forma exponencial los eventos de ocupación ilegal de viviendas, sobre todo en territorio español, ya que con la vigente ley, la policía o cualquier cuerpo representante de la ley podrá llevar a cabo un desalojo sin orden judicial en una vivienda ocupada, siempre y cuando esto se realice en las primeras 48 horas del allanamiento.<br><br>
A partir de estas 48 horas, será necesaria una orden judicial, comenzando un proceso judicial exhaustivo que puede llegar a durar años.<br><br>
Por ello, la única forma de evitar esta situación, asegurándonos un bienestar constante, es mediante la implementación de sistemas de seguridad y vigilancia en nuestras viviendas.<br><br>
A día de hoy existen innumerables empresas que se dedican a esta labor, tales como Securitas, Prosegur, etc...<br><br>
Cada una de ellas tiene su propio sistema y lo que es menos interesante para el consumidor, su propia forma de obtener beneficios. Al llevar a cabo la contratación de alguna de estas empresas, pedirán en ciertos casos un pago previo para llevar a cabo una instalación de todo el sistema de seguridad de la vivienda, y adicionalmente se requerirán cobros mensuales a modo de cuota por el empleo y constante uso de estos mismos sistemas.<br><br>
Por ello, nos hemos centrado en un prototipo que proteja la entrada de la casa de forma activa y de fácil uso para el cliente</p>
</table>
</div></body></html>
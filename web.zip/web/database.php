<?php

$server = 'localhost';
$username = 'administrador';
$password = 'EE6zGqxZL5anUmst';
$database = 'sistema_seguridad';

try {
  $conn = new PDO("mysql:host=$server;dbname=$database;", $username, $password);
} catch (PDOException $e) {
  die('Connection Failed: ' . $e->getMessage());
}

?>
# ESP32-CAM Access Control System
Using an ESP32-CAM to unlock a door when a face is recognised.  A simple access control system based on face recognition with the ESP32-CAM and the Arduino IDE.

![Interface](https://robotzero.one/wp-content/uploads/bfi_thumb/featured-master-1-6qb32y1978bm9yf6ne9nypfey83yf3pvisk7rozvfi8.jpg)

Full details on the blog: https://robotzero.one/access-control-with-face-recognition/

import telebot
import ssl
import sys
 
import paho.mqtt.client as mqtt #import the client1

bot = telebot.TeleBot("1426153334:AAHQMPbEOecaeAlmYdB_5BDiP50AYkacBug")




def on_connect(client, userdata, flags, rc):
	if(rc==0):
		print("cliente conectado")
		global connected
		connected=True
	else:
		print("el cliente no esta conectado")

def on_message(client, userdata, message):
    print('------------------------------')
    print("mensaje recibido: "+ str(message.payload.decode("utf-8")))
    print("topic: " + str(message.topic))
    bot.send_message(chat_id=-486114016, text="se ha conectado: " + str(message.payload.decode("utf-8")))


 
def inicializa():
    connected=False
    messagerecieve=False

    broker_address="138.201.164.206"
    port=1883
    #broker_address="iot.eclipse.org" #use external broker
    client = mqtt.Client("ubicua") #create new instance
    user="root"
    password="EE6zGqxZL5anUmst"
    client.username_pw_set(user,password=password)
    client.on_connect=on_connect
    client.on_message=on_message
    client.connect(broker_address,port)
    client.subscribe('Entrada/entradaCasa')
    #client.publish('esp/test',"string")
    client.loop_forever()

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(message, "Bienvenido al chat")
    bot.reply_to(message, " Comandos:\n EncenderCamara \n ApagarCamara \n Gracias")
    bot.send_message(chat_id=-486114016, text="iniciando chat.")
    inicializa()
		
@bot.message_handler(func=lambda message: True)
def echo_all(message):
        bot.reply_to(message, message.text)
        if(message.text == 'EncenderCamara'):
                #publish.single('/salida1','1',hostname='localhost')
                print("Salida 1 encendida.")
                bot.reply_to(message, "Salida 1 encendida.")
        elif(message.text == 'ApagarCamara'):
               # publish.single('/salida1','0',hostname='localhost')
                print("Salida 1 apagada")
                bot.reply_to(message, "Salida 1 apagada.")
        #print(message)
        print(message.text)
print("iniciando programa")
bot.polling(none_stop=False,timeout=30)
    

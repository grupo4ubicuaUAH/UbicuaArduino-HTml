/ *
   Derechos de autor (c) 2018 Brian Lough. Todos los derechos reservados.
   UniversalTelegramBot - Biblioteca para crear su propio Telegram Bot usando
   ESP8266 o ESP32 en Arduino IDE.
   Esta biblioteca es software gratuito; puedes redistribuirlo y / o
   modificarlo bajo los términos del Público General Menor de GNU
   Licencia publicada por la Free Software Foundation; ya sea
   versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
   Esta biblioteca se distribuye con la esperanza de que sea útil,
   pero SIN NINGUNA GARANTÍA; sin siquiera la garantía implícita de
   COMERCIABILIDAD o APTITUD PARA UN PROPÓSITO PARTICULAR. Ver el GNU
   Licencia pública general menor para obtener más detalles.
   Debería haber recibido una copia de GNU Lesser General Public
   Licencia junto con esta biblioteca; si no, escriba al software libre
   Foundation, Inc., 51 Franklin St, quinto piso, Boston, MA 02110-1301 EE. UU.
 * /

/ *
   **** Nota sobre el mantenimiento de la conexión del cliente ****
   La conexión con el cliente se establece en funciones que implican directamente el uso de
   cliente, es decir, sendGetToTelegram, sendPostToTelegram y
   sendMultipartFormDataToTelegram. Está cerrado al final de
   sendMultipartFormDataToTelegram, pero no al final de sendGetToTelegram y
   sendPostToTelegram, ya que es posible que deban mantener activa la conexión para respose
   / comprobación de respuesta. Reestablecer una conexión y luego perder el tiempo que es
   notable en la experiencia del usuario. Debido a esto, es importante que la conexión
   cerrarse manualmente después de llamar a sendGetToTelegram o sendPostToTelegram por
   llamando a closeClient (); No cerrar la conexión provoca una pérdida de memoria y
   Errores SSL
 * /

# include  " UniversalTelegramBot.h "

# define  ZERO_COPY ( STR ) (( char *) STR.c_str ())
# define  BOT_CMD ( STR ) buildCommand (F (STR))

UniversalTelegramBot :: UniversalTelegramBot ( cadena constante y token, cliente y cliente) {
  updateToken (token);
  esto -> cliente = & cliente;
}

void  UniversalTelegramBot :: updateToken ( cadena constante y token) {
  _token = token;
}

String UniversalTelegramBot :: getToken () {
  return _token;
}

String UniversalTelegramBot :: buildCommand ( const String & cmd) {
  Comando de cadena;

  comando + = F ( " bot " );
  comando + = _token;
  comando + = F ( " / " );
  comando + = cmd;

  comando de retorno ;
}

String UniversalTelegramBot :: sendGetToTelegram ( const String & command) {
  Cuerpo de cadena, encabezados;
  
  // Conéctese con api.telegram.org si aún no está conectado
  if (! cliente-> conectado ()) {
    # ifdef TELEGRAM_DEBUG  
        De serie. println ( F ( " [BOT] Conectando al servidor " ));
    # endif
    if (! cliente-> conectar (TELEGRAM_HOST, TELEGRAM_SSL_PORT)) {
      # ifdef TELEGRAM_DEBUG  
        De serie. println ( F ( " [BOT] Error de conexión " ));
      # endif
    }
  }
  si (cliente-> conectado ()) {

    # ifdef TELEGRAM_DEBUG  
        De serie. println ( " enviando: " + comando);
    # endif  

    cliente-> imprimir ( F ( " OBTENER / " ));
    cliente-> imprimir (comando);
    cliente-> println ( F ( " HTTP / 1.1 " ));
    cliente-> println ( F ( " Host: " TELEGRAM_HOST));
    cliente-> println ( F ( " Aceptar: aplicación / json " ));
    cliente-> println ( F ( " Cache-Control: no-cache " ));
    cliente-> println ();

    readHTTPAnswer (cuerpo, encabezados);
  }

  cuerpo de regreso ;
}

bool  UniversalTelegramBot :: readHTTPAnswer (Cadena y cuerpo, Cadena y encabezados) {
  int ch_count = 0 ;
  unsigned  long ahora = millis ();
  bool finishHeaders = false ;
  bool currentLineIsBlank = true ;
  bool responseReceived = falso ;

  while ( millis () - ahora <longPoll * 1000 + waitForResponse) {
    while (cliente-> disponible ()) {
      char c = cliente-> leer ();
      responseReceived = verdadero ;

      if (! finishHeaders) {
        if (currentLineIsBlank && c == ' \ n ' ) {
          finishHeaders = true ;
        } más {
          encabezados + = c;
        }
      } más {
        if (ch_count <maxMessageLength) {
          cuerpo + = c;
          ch_count ++;
        }
      }

      if (c == ' \ n ' ) currentLineIsBlank = true ;
      otra cosa  si (c =! ' \ r ' currentLineIsBlank =) falsa ;
    }

    if (responseReceived) {
      # ifdef TELEGRAM_DEBUG  
        De serie. println ();
        De serie. println (cuerpo);
        De serie. println ();
      # endif
      romper ;
    }
  }
  return responseReceived;
}

String UniversalTelegramBot :: sendPostToTelegram ( const String & command, carga útil de JsonObject) {

  Cuerpo de cuerda;
  Encabezados de cadena;

  // Conéctese con api.telegram.org si aún no está conectado
  if (! cliente-> conectado ()) {
    # ifdef TELEGRAM_DEBUG  
        De serie. println ( F ( " [Cliente BOT] Conectando al servidor " ));
    # endif
    if (! cliente-> conectar (TELEGRAM_HOST, TELEGRAM_SSL_PORT)) {
      # ifdef TELEGRAM_DEBUG  
        De serie. println ( F ( " [Cliente BOT] Error de conexión " ));
      # endif
    }
  }
  si (cliente-> conectado ()) {
    // POST URI
    cliente-> imprimir ( F ( " POST / " ));
    cliente-> imprimir (comando);
    cliente-> println ( F ( " HTTP / 1.1 " ));
    // Encabezado de host
    cliente-> println ( F ( " Host: " TELEGRAM_HOST));
    // Tipo de contenido JSON
    cliente-> println ( F ( " Tipo de contenido: aplicación / json " ));

    // Longitud del contenido
    int longitud = medidaJson (carga útil);
    cliente-> imprimir ( F ( " Contenido-Longitud: " ));
    cliente-> println (longitud);
    // Fin de los encabezados
    cliente-> println ();
    // cuerpo del mensaje POST
    Extender;
    serializeJson (carga útil, fuera);
    
    cliente-> println (fuera);
    # ifdef TELEGRAM_DEBUG
        De serie. println ( String ( " Publicación: " ) + salida);
    # endif

    readHTTPAnswer (cuerpo, encabezados);
  }

  cuerpo de regreso ;
}

String UniversalTelegramBot :: sendMultipartFormDataToTelegram (
    const String & command, const String & binaryPropertyName, const String & fileName,
    const String & contentType, const String & chat_id, int fileSize,
    MoreDataAvailable moreDataAvailableCallback,
    GetNextByte getNextByteCallback, 
    GetNextBuffer getNextBufferCallback,
    GetNextBufferLen getNextBufferLenCallback) {

  Cuerpo de cuerda;
  Encabezados de cadena;
  
  const String boundary = F ( " ------------------------ b8f610217e83e29b " );

  // Conéctese con api.telegram.org si aún no está conectado
  if (! cliente-> conectado ()) {
    # ifdef TELEGRAM_DEBUG  
        De serie. println ( F ( " [Cliente BOT] Conectando al servidor " ));
    # endif
    if (! cliente-> conectar (TELEGRAM_HOST, TELEGRAM_SSL_PORT)) {
      # ifdef TELEGRAM_DEBUG  
        De serie. println ( F ( " [Cliente BOT] Error de conexión " ));
      # endif
    }
  }
  si (cliente-> conectado ()) {
    String start_request;
    String end_request;
    

    start_request + = F ( " - " );
    start_request + = límite;
    start_request + = F ( " \ r \ n contenido-disposición: formulario-datos; nombre = \" chat_id \ "\ r \ n \ r \ n " );
    start_request + = chat_id;
    start_request + = F ( " \ r \ n "  " - " );
    start_request + = límite;
    start_request + = F ( " \ r \ n contenido-disposición: formulario-datos; nombre = \" " );
    start_request + = binaryPropertyName;
    start_request + = F ( " \" ; nombre de archivo = \ " " );
    start_request + = nombreArchivo;
    start_request + = F ( " \" \ r \ n "  " Tipo de contenido: " );
    start_request + = contentType;
    start_request + = F ( " \ r \ n "  " \ r \ n " );

    end_request + = F ( " \ r \ n "  " - " );
    end_request + = límite;
    end_request + = F ( " - "  " \ r \ n " );

    cliente-> imprimir ( F ( " POST / " ));
    cliente-> imprimir ( buildCommand (comando));
    cliente-> println ( F ( " HTTP / 1.1 " ));
    // Encabezado de host
    cliente-> println ( F ( " Host: " TELEGRAM_HOST)); // corrección de errores - https://github.com/witnessmenow/Universal-Arduino-Telegram-Bot/issues/186
    cliente-> println ( F ( " Usuario-Agente: arduino / 1.0 " ));
    cliente-> println ( F ( " Aceptar: * / * " ));

    int contentLength = fileSize + start_request. longitud () + end_request. longitud ();
    # ifdef TELEGRAM_DEBUG  
        De serie. println ( " Content-Length: " + String (contentLength));
    # endif
    cliente-> imprimir ( F ( " Contenido-Longitud: " ));
    cliente-> println ( String (contentLength));
    cliente-> imprimir ( F ( " Tipo de contenido: multiparte / formulario-datos; límite = " ));
    cliente-> println (límite);
    cliente-> println ( F ( " " ));
    cliente-> imprimir (start_request);

    # ifdef TELEGRAM_DEBUG  
     De serie. print ( " Solicitud de inicio: " + start_request);
    # endif

    if (getNextByteCallback == nullptr ) {
        while ( moreDataAvailableCallback ()) {
            cliente-> escribir (( const  uint8_t *) getNextBufferCallback (), getNextBufferLenCallback ());
            # ifdef TELEGRAM_DEBUG  
             De serie. println ( F ( " Enviando foto desde el búfer " ));
            # endif
            }
    } más {
        # ifdef TELEGRAM_DEBUG  
            De serie. println ( F ( " Enviando foto por binario " ));
        # endif
        búfer de bytes [ 512 ];
        int count = 0 ;
        while ( moreDataAvailableCallback ()) {
            búfer [recuento] = getNextByteCallback ();
            contar ++;
            si (cuenta == 512 ) {
                // rendimiento ();
                # ifdef TELEGRAM_DEBUG  
                    De serie. println ( F ( " Envío de búfer completo de fotografías binarias " ));
                # endif
                cliente-> escribir (( const  uint8_t *) búfer, 512 );
                cuenta = 0 ;
            }
        }
        
        si (cuenta> 0 ) {
            # ifdef TELEGRAM_DEBUG  
                De serie. println ( F ( " Enviando el búfer restante de fotografías binarias " ));
            # endif
            cliente-> escribir (( const  uint8_t *) búfer, contar);
        }
    }

    cliente-> imprimir (end_request);
    # ifdef TELEGRAM_DEBUG  
        De serie. print ( " Fin de la solicitud: " + end_request);
    # endif
    readHTTPAnswer (cuerpo, encabezados);
  }

  closeClient ();
  cuerpo de regreso ;
}


bool  UniversalTelegramBot :: getMe () {
  Respuesta de cadena = sendGetToTelegram ( BOT_CMD ( " getMe " )); // recibir respuesta de telegram.org
  DynamicJsonDocument doc (maxMessageLength);
  DeserializationError error = deserializeJson (doc, ZERO_COPY (respuesta));
  closeClient ();

  if (! error) {
    if (doc. containsKey ( " resultado " )) {
      name = doc [ " resultado " ] [ " FIRST_NAME " ]. como <String> ();
      userName = doc [ " resultado " ] [ " nombre de usuario " ]. como <String> ();
      devuelve  verdadero ;
    }
  }

  devolver  falso ;
}

/ * ********************************************* *******************************
 * SetMyCommands: actualiza la lista de comandos del bot en el servidor de telegramas *
 * (Argumento para pasar: matriz serializada de BotCommand) *
 * PRECAUCIÓN: Todos los comandos deben estar en minúsculas *
 * Devuelve verdadero, si la lista de comandos se actualizó correctamente *
*********************************************** **************************** * /
bool  UniversalTelegramBot :: setMyCommands ( const String & commandArray) {
  Carga útil DynamicJsonDocument (maxMessageLength);
  payload [ " comandos " ] = serializado (commandArray);
  bool enviado = falso ;
  Respuesta de cadena = " " ;
  # si está definido (_debug)
  De serie. println ( F ( " sendSetMyCommands: SEND Post / setMyCommands " ));
  # endif   // definido (_debug)
  unsigned  long sttime = millis ();

  while ( millis () - sttime < 8000ul ) { // bucle durante un tiempo para enviar el mensaje
    response = sendPostToTelegram ( BOT_CMD ( " setMyCommands " ), payload. as <JsonObject> ());
    # Ifdef _debug  
    De serie. println ( " respuesta setMyCommands " + respuesta);
    # endif
    enviado = checkForOkResponse (respuesta);
    si (enviado) romper ;
  }

  closeClient ();
  devolución enviada;
}


/ * ********************************************* **************
 * GetUpdates - función para recibir mensajes de telegram *
 * (Argumento para pasar: el último + 1 mensaje para leer) *
 * Devuelve el número de mensajes nuevos *
*********************************************** ************ * /
int  UniversalTelegramBot :: getUpdates ( desplazamiento largo ) {

  # ifdef TELEGRAM_DEBUG  
    De serie. println ( F ( " OBTENER mensajes de actualización " ));
  # endif
  Comando de cadena = BOT_CMD ( " getUpdates? Offset = " );
  comando + = desplazamiento;
  comando + = F ( " & límite = " );
  comando + = HANDLE_MESSAGES;

  if (longPoll> 0 ) {
    comando + = F ( " & tiempo de espera = " );
    comando + = Cadena (longPoll);
  }
  Respuesta de cadena = sendGetToTelegram (comando); // recibir respuesta de telegram.org

  si (respuesta == " " ) {
    # ifdef TELEGRAM_DEBUG  
        De serie. println ( F ( "¡Se recibió una cadena vacía en respuesta! " ));
    # endif
    // cierra el cliente ya que no hay nada que ver con una cadena vacía
    closeClient ();
    return  0 ;
  } más {
    # ifdef TELEGRAM_DEBUG  
      De serie. print ( F ( " longitud del mensaje entrante " ));
      De serie. println (respuesta. longitud ());
      De serie. println ( F ( " Creando DynamicJsonBuffer " ));
    # endif

    // Analizar la respuesta en el objeto Json
    DynamicJsonDocument doc (maxMessageLength);
    DeserializationError error = deserializeJson (doc, ZERO_COPY (respuesta));
      
    if (! error) {
      # ifdef TELEGRAM_DEBUG  
        De serie. print ( F ( " GetUpdates analizado jsonObj: " ));
        serializeJson (doc, Serial);
        De serie. println ();
      # endif
      if (doc. containsKey ( " resultado " )) {
        int resultArrayLength = doc [ " resultado " ]. tamaño ();
        if (resultArrayLength> 0 ) {
          int newMessageIndex = 0 ;
          // Repasa todos los resultados
          para ( int i = 0 ; i <resultArrayLength; i ++) {
            JsonObject result = doc [ " resultado " ] [i];
            if ( processResult (resultado, newMessageIndex)) newMessageIndex ++;
          }
          // Mantendremos el cliente abierto porque puede haber una respuesta
          // dado
          return newMessageIndex;
        } más {
          # ifdef TELEGRAM_DEBUG  
            De serie. println ( F ( " no hay mensajes nuevos " ));
          # endif
        }
      } más {
        # ifdef TELEGRAM_DEBUG  
            De serie. println ( F ( "La respuesta no contenía 'resultado' " ));
        # endif
      }
    } else { // Error al analizar
      if (response. length () < 2 ) { // Un mensaje demasiado corto. Quizás un problema de conexión
        # ifdef TELEGRAM_DEBUG  
            De serie. println ( F ( " Error de análisis: mensaje demasiado corto " ));
        # endif
      } más {
        // El búfer puede no ser lo suficientemente grande, aumentar el búfer o reducir el número máximo de
        // mensajes
        # ifdef TELEGRAM_DEBUG
            De serie. print ( F ( " No se pudo analizar la actualización, el mensaje también podría ser "
                           " grande para el búfer. Código de error: " ));
            De serie. println (error. c_str ()); // depurar la impresión del error de análisis
        # endif     
      }
    }
    // Cerrar el cliente ya que no se dará respuesta
    closeClient ();
    return  0 ;
  }
}

bool  UniversalTelegramBot :: processResult (resultado de JsonObject, int messageIndex) {
  int update_id = result [ " update_id " ];
  // Compruebe si ya hemos tratado con este mensaje (¡esto no debería suceder!)
  if (last_message_received! = update_id) {
    last_message_received = update_id;
    mensajes [messageIndex]. update_id = update_id;
    mensajes [messageIndex]. texto = F ( " " );
    mensajes [messageIndex]. from_id = F ( " " );
    mensajes [messageIndex]. from_name = F ( " " );
    mensajes [messageIndex]. longitud = 0 ;
    mensajes [messageIndex]. latitud = 0 ;
    mensajes [messageIndex]. reply_to_message_id = 0 ;
    mensajes [messageIndex]. responder_texto = F ( " " );
    mensajes [messageIndex]. query_id = F ( " " );

    if (result. containsKey ( " mensaje " )) {
      JsonObject mensaje = resultado [ " mensaje " ];
      mensajes [messageIndex]. type = F ( " mensaje " );
      mensajes [messageIndex]. from_id = mensaje [ " from " ] [ " id " ]. como <String> ();
      mensajes [messageIndex]. from_name = mensaje [ " from " ] [ " first_name " ]. como <String> ();
      mensajes [messageIndex]. fecha = mensaje [ " fecha " ]. como <String> ();
      mensajes [messageIndex]. chat_id = mensaje [ " chat " ] [ " id " ]. como <String> ();
      mensajes [messageIndex]. chat_title = mensaje [ " chat " ] [ " título " ]. como <String> ();
      mensajes [messageIndex]. hasDocument = false ;
      mensajes [messageIndex]. message_id = mensaje [ " message_id " ]. como < int > ();  // ID de mensaje añadido
      if (message. containsKey ( " texto " )) {
        mensajes [messageIndex]. texto = mensaje [ " texto " ]. como <String> ();
          
      } else  if (message. containsKey ( " ubicación " )) {
        mensajes [messageIndex]. longitud = mensaje [ " ubicación " ] [ " longitud " ]. como < flotar > ();
        mensajes [messageIndex]. latitud   = mensaje [ " ubicación " ] [ " latitud " ]. como < flotar > ();
      } else  if (message. containsKey ( " documento " )) {
        String file_id = mensaje [ " documento " ] [ " file_id " ]. como <String> ();
        mensajes [messageIndex]. file_caption = mensaje [ " título " ]. como <String> ();
        mensajes [messageIndex]. nombre_archivo = mensaje [ " documento " ] [ " nombre_archivo " ]. como <String> ();
        if ( getFile (messages [messageIndex]. file_path , messages [messageIndex]. file_size , file_id) == true )
          mensajes [messageIndex]. hasDocument = true ;
        más
          mensajes [messageIndex]. hasDocument = false ;
      }
      if (message. containsKey ( " reply_to_message " )) {
        mensajes [messageIndex]. Reply_to_message_id = message [ " reply_to_message " ] [ " message_id " ];
        // no es necesario comprobar si contiene la clave ["texto"]. Si no es así, por defecto es nulo
        mensajes [messageIndex]. responder_a_texto = mensaje [ " responder_a_mensaje " ] [ " texto " ]. como <String> ();
      }

    } else  if (result. containsKey ( " channel_post " )) {
      Mensaje de JsonObject = resultado [ " channel_post " ];
      mensajes [messageIndex]. tipo = F ( " canal_post " );
      mensajes [messageIndex]. texto = mensaje [ " texto " ]. como <String> ();
      mensajes [messageIndex]. fecha = mensaje [ " fecha " ]. como <String> ();
      mensajes [messageIndex]. chat_id = mensaje [ " chat " ] [ " id " ]. como <String> ();
      mensajes [messageIndex]. chat_title = mensaje [ " chat " ] [ " título " ]. como <String> ();
      mensajes [messageIndex]. message_id = mensaje [ " message_id " ]. como < int > ();  // ID de mensaje añadido

    } else  if (result. containsKey ( " callback_query " )) {
      Mensaje de JsonObject = resultado [ " callback_query " ];
      mensajes [messageIndex]. type = F ( " callback_query " );
      mensajes [messageIndex]. from_id = mensaje [ " from " ] [ " id " ]. como <String> ();
      mensajes [messageIndex]. from_name = mensaje [ " from " ] [ " first_name " ]. como <String> ();
      mensajes [messageIndex]. texto = mensaje [ " datos " ]. como <String> ();
      mensajes [messageIndex]. fecha = mensaje [ " fecha " ]. como <String> ();
      mensajes [messageIndex]. chat_id = mensaje [ " mensaje " ] [ " chat " ] [ " id " ]. como <String> ();
      mensajes [messageIndex]. reply_to_text = mensaje [ " mensaje " ] [ " texto " ]. como <String> ();
      mensajes [messageIndex]. chat_title = F ( " " );
      mensajes [messageIndex]. query_id = mensaje [ " id " ]. como <String> ();
      mensajes [messageIndex]. message_id = mensaje [ " mensaje " ] [ " message_id " ]. como < int > ();  // ID de mensaje añadido

    } else  if (result. containsKey ( " mensaje_editado " )) {
      Mensaje de JsonObject = resultado [ " mensaje_editado " ];
      mensajes [messageIndex]. tipo = F ( " mensaje_editado " );
      mensajes [messageIndex]. from_id = mensaje [ " from " ] [ " id " ]. como <String> ();
      mensajes [messageIndex]. from_name = mensaje [ " from " ] [ " first_name " ]. como <String> ();
      mensajes [messageIndex]. fecha = mensaje [ " fecha " ]. como <String> ();
      mensajes [messageIndex]. chat_id = mensaje [ " chat " ] [ " id " ]. como <String> ();
      mensajes [messageIndex]. chat_title = mensaje [ " chat " ] [ " título " ]. como <String> ();
      mensajes [messageIndex]. message_id = mensaje [ " message_id " ]. como < int > ();  // ID de mensaje añadido

      if (message. containsKey ( " texto " )) {
        mensajes [messageIndex]. texto = mensaje [ " texto " ]. como <String> ();
          
      } else  if (message. containsKey ( " ubicación " )) {
        mensajes [messageIndex]. longitud = mensaje [ " ubicación " ] [ " longitud " ]. como < flotar > ();
        mensajes [messageIndex]. latitud   = mensaje [ " ubicación " ] [ " latitud " ]. como < flotar > ();
      }
    }
    devuelve  verdadero ;
  }
  devolver  falso ;
}

/ * ********************************************* **********************
 * SendMessage - función para enviar mensaje a telegram *
 * (Argumentos para pasar: chat_id, texto para transmitir y marcado (opcional)) *
*********************************************** ******************** * /
bool  UniversalTelegramBot :: sendSimpleMessage ( const String & chat_id, const String & text,
                                             const String & parse_mode) {

  bool enviado = falso ;
  # ifdef TELEGRAM_DEBUG  
    De serie. println ( F ( " sendSimpleMessage: ENVIAR mensaje simple " ));
  # endif
  unsigned  long sttime = millis ();

  if (text! = " " ) {
    while ( millis () - sttime < 8000ul ) { // bucle durante un tiempo para enviar el mensaje
      Comando de cadena = BOT_CMD ( " sendMessage? Chat_id = " );
      comando + = chat_id;
      comando + = F ( " & texto = " );
      comando + = texto;
      comando + = F ( " & parse_mode = " );
      comando + = parse_mode;
      Respuesta de cadena = sendGetToTelegram (comando);
      # ifdef TELEGRAM_DEBUG  
        De serie. println (respuesta);
      # endif
      enviado = checkForOkResponse (respuesta);
      si (enviado) romper ;
    }
  }
  closeClient ();
  devolución enviada;
}

bool  UniversalTelegramBot :: sendMessage ( const String & chat_id, const String & text,
                                       const String & parse_mode, int message_id) { // agregado message_id

  Carga útil DynamicJsonDocument (maxMessageLength);
  payload [ " chat_id " ] = chat_id;
  payload [ " texto " ] = texto;

  si (message_id! = 0 )
    payload [ " message_id " ] = message_id; // añadido message_id

  if (parse_mode! = " " )
    payload [ " parse_mode " ] = parse_mode;

  return  sendPostMessage (payload. as <JsonObject> (), message_id); // si el ID del mensaje == 0 entonces la edición es falsa, de lo contrario la edición es verdadera
}

bool  UniversalTelegramBot :: sendMessageWithReplyKeyboard (
    const String & chat_id, const String & text, const String & parse_mode, const String & keyboard,
    bool de cambio de tamaño, bool Onetime, bool selectiva) {
    
  Carga útil DynamicJsonDocument (maxMessageLength);
  payload [ " chat_id " ] = chat_id;
  payload [ " texto " ] = texto;

  if (parse_mode! = " " )
    payload [ " parse_mode " ] = parse_mode;

  JsonObject replyMarkup = carga útil. createNestedObject ( " respuesta_marcado " );
    
  replyMarkup [ " teclado " ] = serializado (teclado);

  // Telegram establece estos valores por defecto en falso, por lo que para disminuir el tamaño del
  // carga útil solo los enviaremos si es necesario
  si (cambiar el tamaño)
    replyMarkup [ " resize_keyboard " ] = cambiar el tamaño;

  si (una vez)
    ReplyMarkup [ " one_time_keyboard " ] = oneTime;

  si (selectivo)
    replyMarkup [ " selectivo " ] = selectivo;

  return  sendPostMessage (payload. as <JsonObject> ());
}

bool  UniversalTelegramBot :: sendMessageWithInlineKeyboard ( const String & chat_id,
                                                         const Cadena y texto,
                                                         const String & parse_mode,
                                                         const String y teclado,
                                                         int message_id) {    // añadido message_id

  Carga útil DynamicJsonDocument (maxMessageLength);
  payload [ " chat_id " ] = chat_id;
  payload [ " texto " ] = texto;

  si (message_id! = 0 )
    payload [ " message_id " ] = message_id; // añadido message_id
    
  if (parse_mode! = " " )
    payload [ " parse_mode " ] = parse_mode;

  JsonObject replyMarkup = carga útil. createNestedObject ( " respuesta_marcado " );
  replyMarkup [ " inline_keyboard " ] = serializado (teclado);
  return  sendPostMessage (payload. as <JsonObject> (), message_id); // si el ID del mensaje == 0 entonces la edición es falsa, de lo contrario la edición es verdadera
}

/ * ********************************************* **********************
 * SendPostMessage - función para enviar un mensaje a un telegrama *
 * (Argumentos para pasar: chat_id, texto para transmitir y marcado (opcional)) *
*********************************************** ******************** * /
bool  UniversalTelegramBot :: sendPostMessage (carga útil de JsonObject, edición bool ) { // agregado message_id

  bool enviado = falso ;
  # ifdef TELEGRAM_DEBUG
    De serie. print ( F ( " sendPostMessage: SEND Post Message: " ));
    serializeJson (carga útil, serial);
    De serie. println ();
  # endif 
  unsigned  long sttime = millis ();

  if (payload. containsKey ( " texto " )) {
    while ( millis () <sttime + 8000 ) { // bucle durante un tiempo para enviar el mensaje
        String response = sendPostToTelegram ((editar? BOT_CMD ( " editMessageText " ): BOT_CMD ( " sendMessage " )), payload); // si edit es verdadero, enviamos un CMD editMessageText
         # ifdef TELEGRAM_DEBUG  
        De serie. println (respuesta);
      # endif
      enviado = checkForOkResponse (respuesta);
      si (enviado) romper ;
    }
  }

  closeClient ();
  devolución enviada;
}

String UniversalTelegramBot :: sendPostPhoto (carga útil de JsonObject) {

  bool enviado = falso ;
  Respuesta de cadena = " " ;
  # ifdef TELEGRAM_DEBUG  
    De serie. println ( F ( " sendPostPhoto: ENVIAR Post Photo " ));
  # endif
  unsigned  long sttime = millis ();

  if (payload. containsKey ( " foto " )) {
    while ( millis () - sttime < 8000ul ) { // bucle durante un tiempo para enviar el mensaje
      respuesta = sendPostToTelegram ( BOT_CMD ( " enviarFoto " ), carga útil);
      # ifdef TELEGRAM_DEBUG  
        De serie. println (respuesta);
      # endif
      enviado = checkForOkResponse (respuesta);
      si (enviado) romper ;
      
    }
  }

  closeClient ();
  respuesta de retorno ;
}

Cadena UniversalTelegramBot :: sendPhotoByBinary (
    const String & chat_id, const String & contentType, int fileSize,
    MoreDataAvailable moreDataAvailableCallback,
    GetNextByte getNextByteCallback, GetNextBuffer getNextBufferCallback, GetNextBufferLen getNextBufferLenCallback) {

  # ifdef TELEGRAM_DEBUG  
    De serie. println ( F ( " sendPhotoByBinary: ENVIAR foto " ));
  # endif

  Respuesta String = sendMultipartFormDataToTelegram ( " sendPhoto " , " foto " , " img.jpg " ,
    contentType, chat_id, fileSize,
    moreDataAvailableCallback, getNextByteCallback, getNextBufferCallback, getNextBufferLenCallback);

  # ifdef TELEGRAM_DEBUG  
    De serie. println (respuesta);
  # endif

  respuesta de retorno ;
}

String UniversalTelegramBot :: sendPhoto ( const String & chat_id, const String & photo,
                                       const String & caption,
                                       bool disable_notification,
                                       int reply_to_message_id,
                                       const String & keyboard) {

  Carga útil DynamicJsonDocument (maxMessageLength);
  payload [ " chat_id " ] = chat_id;
  carga útil [ " foto " ] = foto;

  si (título. longitud ()> 0 )
      payload [ " caption " ] = título;

  if (disable_notification)
      payload [ " disable_notification " ] = disable_notification;

  if (responder_a_id_mensaje && respuesta_a_mensaje_id! = 0 )
      payload [ " reply_to_message_id " ] = respuesta_to_message_id;

  if (keyboard. length ()> 0 ) {
    JsonObject replyMarkup = carga útil. createNestedObject ( " respuesta_marcado " );
    replyMarkup [ " teclado " ] = serializado (teclado);
  }

  return  sendPostPhoto (payload. as <JsonObject> ());
}

bool  UniversalTelegramBot :: checkForOkResponse ( cadena constante y respuesta) {
  int last_id;
  DynamicJsonDocument doc (respuesta. Longitud ());
  deserializeJson (doc, respuesta);

  // Guardar el último message_id enviado
  last_id = doc [ " resultado " ] [ " message_id " ];
  if (last_id> 0 ) last_sent_message_id = last_id;

  return doc [ " ok " ] | falsa ;  // el valor predeterminado es falso, pero esto es más explícito y claro
}

bool  UniversalTelegramBot :: sendChatAction ( const String & chat_id, const String & text) {

  bool enviado = falso ;
  # ifdef TELEGRAM_DEBUG  
    De serie. println ( F ( " ENVIAR Mensaje de acción de chat " ));
  # endif
  unsigned  long sttime = millis ();

  if (text! = " " ) {
    while ( millis () - sttime < 8000ul ) { // bucle durante un tiempo para enviar el mensaje
      String command = BOT_CMD ( " sendChatAction? Chat_id = " );
      comando + = chat_id;
      comando + = F ( " & acción = " );
      comando + = texto;

      Respuesta de cadena = sendGetToTelegram (comando);

      # ifdef TELEGRAM_DEBUG  
        De serie. println (respuesta);
      # endif
      enviado = checkForOkResponse (respuesta);

      si (enviado) romper ;
      
    }
  }

  closeClient ();
  devolución enviada;
}

void  UniversalTelegramBot :: closeClient () {
  si (cliente-> conectado ()) {
    # ifdef TELEGRAM_DEBUG  
        De serie. println ( F ( " Cliente de cierre " ));
    # endif
    cliente-> detener ();
  }
}

bool  UniversalTelegramBot :: getFile (String & file_path, long & file_size, const String & file_id)
{
  Comando de cadena = BOT_CMD ( " getFile? File_id = " );
  comando + = file_id;
  Respuesta de cadena = sendGetToTelegram (comando); // recibir respuesta de telegram.org
  DynamicJsonDocument doc (maxMessageLength);
  DeserializationError error = deserializeJson (doc, ZERO_COPY (respuesta));
  closeClient ();

  if (! error) {
    if (doc. containsKey ( " resultado " )) {
      file_path = F ( " https://api.telegram.org/file/ " );
      file_path + = buildCommand (doc [ " resultado " ] [ " file_path " ]);
      tamaño_archivo = doc [ " resultado " ] [ " tamaño_archivo " ]. como < largo > ();
      devuelve  verdadero ;
    }
  }
  devolver  falso ;
}

bool  UniversalTelegramBot :: answerCallbackQuery ( const String & query_id, const String & text, bool show_alert, const String & url, int cache_time) {
  Carga útil DynamicJsonDocument (maxMessageLength);

  payload [ " callback_query_id " ] = query_id;
  payload [ " show_alert " ] = show_alert;
  payload [ " cache_time " ] = cache_time;

  if (texto. longitud ()> 0 ) carga útil [ " texto " ] = texto;
  if (url. length ()> 0 ) payload [ " url " ] = url;

  Respuesta String = sendPostToTelegram ( BOT_CMD ( " answerCallbackQuery " ), la carga útil. Como <JSONObject> ());
  # Ifdef _debug  
     De serie. print ( F ( " respuesta answerCallbackQuery: " ));
     De serie. println (respuesta);
  # endif
  bool answer = checkForOkResponse (respuesta);
  closeClient ();
  devolver respuesta;
}